package com.example.contactscontract.adapter;

public class UserAdapter {
    public String name;
    public String hometown;

    public void User(String name, String hometown) {
        this.name = name;
        this.hometown = hometown;
    }
}

