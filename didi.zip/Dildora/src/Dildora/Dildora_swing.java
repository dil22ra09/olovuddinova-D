package Dildora;
import javax.swing.*;    
import java.awt.event.*;  
	
public class Dildora_swing {
	public static void main(String[] args) {    
	    JFrame f=new JFrame("Password Field Example");    
	      final JLabel label = new JLabel();            
	     label.setBounds(40,300, 400,100);  
	      final JPasswordField value = new JPasswordField();   
	   value.setBounds(100,75,100,30);   
	    JLabel l1=new JLabel("First name:");    
	         l1.setBounds(20,20, 80,30);    
	         JLabel l2=new JLabel("Last name:");    
	        l2.setBounds(20,75, 80,30);
	        JLabel l3=new JLabel("Email:");    
	        l3.setBounds(20,110, 80,30);    
	          JButton b = new JButton("Login");  
	          b.setBounds(180,160, 80,30);    
	       JTextField  t1 = new JTextField();  
	        t1.setBounds(100,20, 100,30); 
	        JTextField t2  = new JTextField();  
	        t2.setBounds(100,20, 100,30); 
	       final   JTextField  t3 = new JTextField();  
	        t3.setBounds(100,20, 100,30);
	              f.add(value); f.add(l1); f.add(label); f.add(l2); f.add(l3); f.add(b); f.add(t1); f.add(t2); f.add(t3); 
	                  f.setSize(600,600);    
	                 f.setLayout(null);    
	                  f.setVisible(true);     
	                  b.addActionListener(new ActionListener() {  
	                 public void actionPerformed(ActionEvent e) {       
	                	 String data = "First name:" + t1.getText();  
		                 data += ", Password: "  
		                		 
	                		 
	                + new String(value.getPassword());   
	                    label.setText(data);          
	               }  
	              });   
	}
}


	  

	