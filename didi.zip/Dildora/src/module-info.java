module Dildora {
	requires java.desktop;
}